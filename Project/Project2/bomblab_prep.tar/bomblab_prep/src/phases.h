extern void phase_1(char *input);
extern void phase_2(char *input);
