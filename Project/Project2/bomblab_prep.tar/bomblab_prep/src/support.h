void read_four_ints(char *input, int *numbers);
char *read_line(void);
void explode_bomb(void);
void phase_defused(void);